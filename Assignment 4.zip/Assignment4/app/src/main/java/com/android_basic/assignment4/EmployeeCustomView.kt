package com.android_basic.assignment4

import android.content.Context
import android.util.AttributeSet
import android.view.LayoutInflater
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import com.android_basic.assignment4.model.Employee

/***
 * Created by HoangRyan aka LilDua on 10/4/2023.
 */
class EmployeeCustomView (context: Context, attrs: AttributeSet?) : LinearLayout(context, attrs) {

    fun bind(employee: Employee) {
        val avatar = findViewById<ImageView>(R.id.image_Avatar)
        val name = findViewById<TextView>(R.id.text_name)
        val checkbox = findViewById<CheckBox>(R.id.checkbox)

        avatar.setImageResource(employee.avatar)
        name.text = "${employee.id} - ${employee.name}"
        checkbox.isChecked = employee.isSelected
    }
}